﻿namespace _08.Military_Elite
{
    using Controllers;

    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
