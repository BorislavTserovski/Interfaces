﻿namespace _08.Military_Elite.Interfaces
{
    public interface IPrivate : ISoldier
    {
        double Salary { get; }
    }
}